COscillation = Core.class()

function COscillation:init(xspeed, xamplitudex, xamplitudey)
	self.vx = 0
	self.vy = 0
	self.speed = xspeed
	self.amplitudex = xamplitudex
	self.amplitudey = xamplitudey
end
