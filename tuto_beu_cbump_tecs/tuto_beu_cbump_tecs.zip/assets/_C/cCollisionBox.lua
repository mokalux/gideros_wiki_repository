CCollisionBox = Core.class()

function CCollisionBox:init(xcollwidth, xcollheight)
	self.w = xcollwidth
	self.h = xcollheight
end
