CDistance = Core.class()

function CDistance:init(xstartpos, dx, dy)
	self.startpos = xstartpos
	self.dx = dx -- delta x
	self.dy = dy -- delta y
end
